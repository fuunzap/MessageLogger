<h1 align="center">Welcome to MessageLoggerV2 for Lightcord!</h1>
<p>
</p>

# Information:
### This repository contains modified MLv2 (MessageLoggerV2) from Lighty, modified to work on Lightcord (Custom Discord Client)
### Lighty, the author of this plugin decided to block Lightcord.

# Bugs:
[HERE](https://github.com/extremegrief1/MessageLogger-Lightcord/issues)

# Installation:
### Download files from: https://github.com/extremegrief1/MessageLogger-Lightcord/releases/tag/1.7.69
### Put the plugin files in the %AppData%\Lightcord_BD\plugins.
### Turn off "Scan Plugins" option from Lightcord settings, else it will detect plugin as not safe as it's not signed.
### Fully close Lightcord from System Tray.
### Restart Lightcord, and MLv2 should work now.
